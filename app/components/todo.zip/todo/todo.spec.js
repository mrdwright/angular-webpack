import todo from './todo.controller';

describe('todo', () => {

  describe('TodoController', () => {
    // let ctrl;

    // beforeEach(() => {
    //   angular.mock.module(todo);

    //   angular.mock.inject(($controller) => {
    //     ctrl = $controller('TodoController', {});
    //   });
    // });

    it('should contain the starter url', () => {
      expect(1).toBe(1);
    });
  });
});