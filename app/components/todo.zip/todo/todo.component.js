import template from './todo.html';
import controller from './todo.controller';
import './todo.scss';

const TodoComponent = { 
  bindings: {
    todoData: '<'
  },
  template,
  controller
};

export default TodoComponent;